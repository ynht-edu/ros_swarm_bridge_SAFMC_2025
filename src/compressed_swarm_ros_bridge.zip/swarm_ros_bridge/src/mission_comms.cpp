#include "mission_comms.hpp"

namespace swarm_ros_bridge {
  MissionComms::MissionComms(ros::NodeHandle& nh) : nh_(nh), loop_rate_(50) {
    // publisher
    position_pub_ = nh_.advertise<geometry_msgs::PoseStamped>("drone1/position", 1000);
    payload_drop_status_pub_ = nh_.advertise<mission_msgs::PayloadDropStatus>("drone1/payload_drop_status", 1000);
    #if DRONE == 1
    payload_drop_cmd_pub_ = nh_.advertise<mission_msgs::PayloadDropCommand>("drone1/payload_drop_command", 1000);
    #endif 

    // subscriber
    comp_position_sub_ = nh_.subscribe("drone2/position", 1000, &MissionComms::callbackCompPosition, this);
    comp_payload_drop_status_sub_ = nh_.subscribe("drone2/payload_drop_status", 1000, &MissionComms::callbackCompPosition, this);
    //payload_drop_cmd_sub_ = nh_.subscribe("drone1/payload_drop_command", 1000, &MissionComms::callbac)

    // parameters
    nh_.param("drone_id", drone_id_, 0);
    std::vector<double> temp_pos_(3, 0);
    nh_.param<std::vector<double>>("position_diff", temp_pos_, std::vector<double>{0, 100, 0});
    std::copy(temp_pos_.begin(), temp_pos_.end(), position_diff_.begin());
    nh_.param<std::vector<double>>("target_position_1", temp_pos_, std::vector<double>{0, 0, 0});
    std::copy(temp_pos_.begin(), temp_pos_.end(), target_position_[0].begin());
    nh_.param<std::vector<double>>("target_position_2",  temp_pos_, std::vector<double>{0, 0, 0});
    std::copy(temp_pos_.begin(), temp_pos_.end(), target_position_[1].begin());


  }

  MissionComms::~MissionComms() {
    ROS_INFO("Mission comms killed");
  }

  void MissionComms::dropPayload(){
    
  }

  int MissionComms::angleToPWM(float angle) {
    angle = std::max(ANGLE_MIN, std::min(angle, ANGLE_MAX));
    
    float pwm = PWM_MIN + (angle / (ANGLE_MAX - ANGLE_MIN)) * 
        (PWM_MAX - PWM_MIN);
    return static_cast<int>(pwm);
  }

  void MissionComms::setServoAngle(){

  }

  void MissionComms::syncCoordinate(){

  }

#if DRONE == 1
  void MissionComms::sendDropCommand(){

  }
#endif

  void MissionComms::callbackCompPosition(const geometry_msgs::PoseStamped::ConstPtr& msg){
    comp_position_ = {msg->pose.position.x, msg->pose.position.y, msg->pose.position.z};
  }

  void MissionComms::callbackCompPayloadDropStatus(const mission_msgs::PayloadDropStatus::ConstPtr& msg){
    //
  }

  void MissionComms::callbackCompPayloadDropCmd(const mission_msgs::PayloadDropCommand::ConstPtr& msg){
    //
  }
}
