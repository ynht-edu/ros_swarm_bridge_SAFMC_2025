#include "mission_comms.hpp"

int main(int argc, char **argv){
  ros::init(argc, argv, "mission_comms");
  ros::NodeHandle nh;
  auto comms = swarm_ros_bridge::MissionComms(nh);
  ros::spin();
  return 0;
}
