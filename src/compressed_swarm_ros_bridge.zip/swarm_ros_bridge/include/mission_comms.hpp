#ifndef __MISSION_COMMS__
#define __MISSION_COMMS__

#define DRONE 1

#include <ros/ros.h>
#include <ros/console.h>
#include "uav_config.hpp"

#include <sensor_msgs/Imu.h>
#include <geometry_msgs/Twist.h>
#include <std_msgs/String.h>
// SAFMC 2025
#include <geometry_msgs/PoseStamped.h>
#include <mission_msgs/PayloadDropStatus.h>
#include <mission_msgs/PayloadDropCommand.h>

namespace swarm_ros_bridge {
class MissionComms {
  public:
    MissionComms(ros::NodeHandle &nh);
    ~MissionComms();

    void dropPayload();
    void setServoAngle();
    void syncCoordinate();
#if DRONE == 1
    void sendDropCommand();
#endif
    void getCompanionDronePosition();
  private:
    // ros utility
    ros::Rate loop_rate_;
    ros::NodeHandle nh_;
    
    // variables
    std::array<std::array<double, 3>, 2> target_position_; // x, y, z   posisi hotspot drone 1
    std::array<double, 3> curr_position_;
    std::array<double, 3> comp_position_; // x, y, z     comp = companion, drone temennya
    int drone_id_; 
    std::array<double, 3> position_diff_; // x, y, z    buat sinkronisasi koordinat
                             
    // constants
    const int SERVO_CHANNEL = 9;
    const int PWM_MIN = 1000;
    const int PWM_MAX = 2000;
    const float ANGLE_MIN = 0.0;
    const float ANGLE_MAX = 180.0;
    

    // function
    int angleToPWM(float angle);
    int swarmDistance();

    // publisher
    ros::Publisher position_pub_;
    ros::Publisher payload_drop_status_pub_;
    ros::Publisher rc_override_pub_;
#if DRONE == 1
    ros::Publisher payload_drop_cmd_pub_;
#endif

    // subscriber
    ros::Subscriber curr_position_sub_;
    ros::Subscriber comp_position_sub_;
    ros::Subscriber comp_payload_drop_status_sub_;
    ros::Subscriber payload_drop_cmd_sub_;
    
    
    // callbacks
    void callbackCurrPositionSub(const geometry_msgs::PoseStamped::ConstPtr& msg);
    void callbackCompPosition(const geometry_msgs::PoseStamped::ConstPtr& msg);
    void callbackCompPayloadDropStatus(const mission_msgs::PayloadDropStatus::ConstPtr& msg);
    void callbackCompPayloadDropCmd(const mission_msgs::PayloadDropCommand::ConstPtr& msg);
    void callbackAvoidCompDrone();
};
}

#endif
