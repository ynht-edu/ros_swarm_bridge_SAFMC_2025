#ifndef __UAV_CONFIG__
#define __UAV_CONFIG__

namespace swarm_ros_bridge {
  const int SERVO_CHANNEL = 9;
  const int PWM_MIN = 1000;
  const int PWM_MAX = 2000;
  const float ANGLE_MIN = 0.0;
  const float ANGLE_MAX = 180.0;
}

#endif
